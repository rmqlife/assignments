import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;


public class DNATable {
	Map<String,Integer> code = new HashMap<String,Integer>();
	
	DNATable(String filename)
	{
		File file = new File(filename);
		
		try{
			if (file.isFile() && file.exists())
			{	
				InputStreamReader read = new InputStreamReader(new FileInputStream(file), "GBK");   
				BufferedReader bufferedReader = new BufferedReader(read);   
				String lineTXT = null;
				String before_a =null;
				String a;
				int ord=0;
				while ((lineTXT = bufferedReader.readLine()) != null) 
				{   
					String[] temp = lineTXT.split("\t");
					a=temp[1];
					if (!a.equals(before_a)){
						System.out.println(a);
						ord++;
					}
					before_a=a;
					code.put(temp[0], ord);
				}   
				read.close();
			}
		}catch(IOException e){
			
		}
	}
	
	public int get(String name)
	{
		System.out.println(name);
		return code.get(name);
	}

	
}
