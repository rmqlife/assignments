import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;


public class Example {
	int data[];
	Example(String s){
//		System.out.println(s);
		data=new int[s.length()];
		for (int i=0;i<s.length();i++){
			switch (s.charAt(i)){
			case 'A':data[i]=0;break;
			case 'T':data[i]=3;break;
			case 'G':data[i]=2;break;
			case 'C':data[i]=1;break;
			}
		}
	}
	
	void change2bit()
	{
		int[] temp=new int[data.length*2];
		for (int i=0;i<data.length;i++)
		{
			temp[i*2]=data[i]%2;
			temp[i*2+1]=data[i]/2;
		}
		this.data=temp;
	}
	
	
	
	Example(String s,DNATable table){
		data=new int[s.length()-3];
		for(int i=0;i<data.length;i++)
		{
			String t=s.substring(i, i+3);
			data[i]=table.get(t);
		}
	}
	
	void print()
	{
		for (int i=0;i<data.length;i++)
		{
			System.out.print(data[i]+" ");
		}
		System.out.println();
	}
	void print(BufferedWriter out) throws IOException
	{
		for (int i=0;i<data.length;i++)
		{
			if (i<data.length-1)
				out.write(data[i]+",");
			else
				out.write(data[i]+"\n");
		}
	}
	void print(BufferedWriter out,int[] choose) throws IOException
	{
		for (int i=0;i<choose.length;i++)
		{
			if (i<choose.length-1)
				out.write(data[choose[i]]+",");
			else
				out.write(data[choose[i]]+"\n");
		}
	}
}
