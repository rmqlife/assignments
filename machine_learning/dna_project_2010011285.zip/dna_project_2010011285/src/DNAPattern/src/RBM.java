import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class RBM {
	BUnit[][] hidden;
	BUnit[][] visable;
	double [][] w;
	double []b;
	double []c;
	double speed=1;
	int times=2;
	List<Example> samples=new ArrayList<Example>();
	double probTable[];
	
	void setVisable(double input[])
	{
		for(int i=0;i<visable.length;i++)
			visable[0][i].state=input[i];
	}
	
	void output(BUnit b[])
	{
		for(int i=0;i<b.length;i++)
		{
			System.out.print(b[i].state+" ");
		}
		System.out.println();
	}
	
	void outputProb(BUnit b[])
	{
		for(int i=0;i<b.length;i++)
		{
			System.out.print(b[i].prob+" ");
		}
		System.out.println();
	}
	
	void recall(double input[])
	{
		setVisable(input);
		updateHidden(0);
		output(hidden[0]);
	}
	
	
	void init(int n_visable,int n_hidden)
	{
		visable=new BUnit[times][n_visable];
		hidden=new BUnit[times][n_hidden];
		
		System.out.println("visable units: "+n_visable+" hidden units: "+n_hidden);
		
		for (int t=0;t<times;t++)
			for (int i=0;i<hidden[0].length;i++){
				hidden[t][i]=new BUnit();
			}
		
		for (int t=0;t<times;t++)
			for (int i=0;i<visable[0].length;i++){
				visable[t][i]=new BUnit();
			}
				
		
		w=new double[n_visable][n_hidden];
		b=new double[n_visable];
		c=new double[n_hidden];
			
		for	(int i=0;i<n_visable;i++)
			for	(int j=0;j<n_hidden;j++){
//				System.out.println(i+" "+j);
				w[i][j]=Math.random()*0.1-0.1;
			}
		//b c init
	}

	
	void updateHidden(int time)
	{
		for (int j=0;j<hidden[0].length;j++){
			hidden[time][j].prob=c[j];
			for (int i=0;i<visable[0].length;i++){
				hidden[time][j].prob+=visable[time][i].state*w[i][j];
			}
			hidden[time][j].update();
		}
	}
	
	
	
	void updateVisable(int time)
	{
		for (int i=0;i<visable[0].length;i++){
			visable[time][i].prob=b[i];
			for (int j=0;j<hidden[0].length;j++){
				visable[time][i].prob+=hidden[time][j].state*w[i][j];
			}
			visable[time][i].update();
		}
	}
	
	
	void updateW()
	{
		for (int i=0;i<visable[0].length;i++)
			for (int j=0;j<hidden[0].length;j++){
				double delta=visable[0][i].prob
						* hidden[0][j].prob 
						-visable[1][i].prob 
						* hidden[1][j].prob ;	
				delta=delta*speed;
				
				w[i][j]+=delta;
			}
		
		for (int i=0;i<visable[0].length;i++){
			double delta=visable[0][i].prob
					-visable[1][i].prob;
			delta=delta*speed;
//			System.out.println(delta);
			b[i]+=delta;
		}
		
		for (int i=0;i<hidden[0].length;i++){
			double delta=hidden[0][i].prob * hidden[0][i].state
					-hidden[1][i].prob * hidden[1][i].state;
			delta=delta*speed;
			
			c[i]+=delta;
		}
	}
	
	
	void train(int times)
	{
		for(int i=0;i<times;i++){
			updateHidden(0);
			updateVisable(1);
			updateHidden(1);
			updateW();
//			outputProb(visable[1]);
		}
	}
	
	void setVisableBySample(Example e)
	{
		assert(e.data.length==visable[0].length);
		for(int i=0;i<visable[0].length;i++){
//			assert(e.x[i]<probTable.length);
			visable[0][i].state=e.data[i];
			visable[0][i].prob=probTable[e.data[i]];
//			visable[0][i].prob=e.x[i];
			visable[0][i].update();
			if (((int)visable[0][i].state)>0)
				visable[0][i].prob=1;
			else
				visable[0][i].prob=0;
		}
	}
	

	
	void preTrain(int iter1,int iter2)
	{
		initProbTable(2);
		for (int t=0;t<iter1;t++){
			for (int i=0;i<samples.size();i++)
			{
				Example e=samples.get(i);
				setVisableBySample(e);
//				outputProb(visable[0]);
				train(iter2);
				outputProb(visable[1]);
			}
		}
	}
	
	
	
	
	
	void initProbTable(int kStates)
	{
		probTable=new double[kStates];
		double tt=0;
		for (int i=0;i<kStates;i++)
		{
			probTable[i]=Math.pow(Math.E, i);
			tt+=probTable[i];
		}
		
		for (int i=0;i<kStates;i++)
		{
			probTable[i]=probTable[i]/tt;
		}
	}
	
	
	
	RBM(List<Example> samples,int n_visable, int n_hidden){
		init(n_visable,n_hidden);
		this.samples=samples;
	}
	
	void recallSamples()
	{
		for (int i=0;i<samples.size();i++)
		{
			samples.get(i).print();
		}
	}
	
	
}
