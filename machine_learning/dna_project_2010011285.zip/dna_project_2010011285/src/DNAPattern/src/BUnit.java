
public class BUnit {
	double prob;
	double state;

	void update()
	{
		prob=sigmoid(prob);
		assert(prob>0);
		if (prob>Math.random())
			state=1;
		else
			state=0;
//		state=prob;
	}
	
	double sigmoid(double y)
	{
		return 1/(Math.pow(Math.E, -y)+1);
	}
}
