import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class DNAPattern {
	List<Example> samples=new ArrayList<Example>();

	void initSamples(String filename,DNATable dt,boolean rawTag)
	{
		File file = new File(filename);
		try{
			if (file.isFile() && file.exists())
			{	
				InputStreamReader read = new InputStreamReader(new FileInputStream(file), "GBK");   
				BufferedReader bufferedReader = new BufferedReader(read);   
				String lineTXT = null;   
				while ((lineTXT = bufferedReader.readLine()) != null) 
				{   
//					System.out.println(lineTXT);
					if (lineTXT.charAt(0)=='>')
						continue;
					Example sample;
					if (!rawTag)
						sample=new Example(lineTXT,dt);
					else {
						sample=new Example(lineTXT);
					}
					samples.add(sample);
				}   
				read.close();
			}
		}catch(IOException e){
			
		}
	}
	
	
	
	
	
	
	static public void main(String args[]) throws IOException{
		DNAPattern p=new DNAPattern();
		DNATable dt=null;//=new  DNATable("/Users/jzd/Documents/testfile/dna_table.txt");
//		p.initSamples("/Users/jzd/Documents/testfile/Os_UandD250seq.txt",dt);
		p.initSamples("/Users/jzd/Documents/testfile/Os_UandD250seq.txt",dt,true);
		
		File f=new File("/Users/jzd/Documents/testfile/dna_f.csv");
		if (f.exists()==false) 
			f.createNewFile();
		BufferedWriter output = new BufferedWriter(new FileWriter(f));
		
		ArrayFile af=new ArrayFile();
		int []choose=af.read("/Users/jzd/Documents/testfile/selectfeature.txt");

		
//		for (int i=0;i<p.samples.get(0).data.length;i++)
//		{
//			output.write("no"+i);
//			if (i<p.samples.get(0).data.length-1)
//				output.write(",");
//			else
//				output.write('\n');
//		}
		
		for (int i=0;i<choose.length;i++)
		{
			output.write("no"+i);
			if (i<choose.length-1)
				output.write(",");
			else
				output.write('\n');
		}
				for (int i=0;i<choose.length;i++)
			System.out.println(choose[i]);
		for (int i=0;i<p.samples.size();i++){
//			p.samples.get(i).change2bit();
			p.samples.get(i).print(output,choose);
//			p.samples.get(i).print();
		}
		
		
		output.close();
		
//		RBM rbm=new RBM(p.samples.subList(0, 1), p.samples.get(0).data.length, 100);
//		rbm.preTrain(100, 20);
//		rbm.recallSamples();
	}
	
}
