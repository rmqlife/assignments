import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class ArrayFile {
	
	int[] read(String filename){
	int[] ans=null;
	File file = new File(filename);
	try{
		if (file.isFile() && file.exists())
		{	
			InputStreamReader read = new InputStreamReader(new FileInputStream(file), "GBK");   
			BufferedReader bufferedReader = new BufferedReader(read);   
			String lineTXT = null;   
			lineTXT = bufferedReader.readLine();  
			String[] a=lineTXT.split(",");
			ans=new int[a.length];
			for (int i=0;i<a.length;i++)
				ans[i]=Integer.parseInt(a[i]);
			read.close();
		}
	}catch(IOException e){
		
	}
	return ans;
	}
}
