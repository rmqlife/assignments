import java.io.File;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
public class Ensemble {
	public static void main(String[] args) throws Exception {
		// Classifier m_classifier = new RandomForest();
		Classifier m_classifier = new J48();
		// Classifier m_classifier = new NaiveBayes();
//		 Classifier m_classifier = new LibSVM();
		ArffLoader atf = new ArffLoader();
		AdaBoost adaboost=new AdaBoost();
		Bagging bagging=new Bagging();
		bagging.setClassifier(m_classifier);
		
		try {
			File inputFile = new File(
					"/Users/jzd/Desktop/weka-3-6-9/data/spam.arff");// 测试语料文件
			atf.setFile(inputFile);
			Instances instancesTrain = atf.getDataSet(); // 读入训练文件
			atf.setFile(inputFile);
			Instances instancesTest = atf.getDataSet(); // 读入测试文件
			instancesTest.setClassIndex(0); // 设置分类属性所在行号（第一行为0号），instancesTest.numAttributes()可以取得属性总数
			double sum = instancesTest.numInstances(), // 测试语料实例数
			right = 0.0f;
			instancesTrain.setClassIndex(0);
			m_classifier.buildClassifier(instancesTrain); // 训练
			for (int i = 0; i < sum; i++)// 测试分类结果
			{
				if (m_classifier.classifyInstance(instancesTest.instance(i)) == instancesTest
						.instance(i).classValue())				{
					right++;
				}
			}
			System.out.println("RandomForest classification precision:"+ (right / sum));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
