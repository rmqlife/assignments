
import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import weka.classifiers.RandomizableIteratedSingleClassifierEnhancer;
import weka.core.AdditionalMeasureProducer;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Randomizable;
import weka.core.TechnicalInformation;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;
import weka.core.TechnicalInformationHandler;
import weka.core.Utils;
import weka.core.WeightedInstancesHandler;


public class Bagging extends RandomizableIteratedSingleClassifierEnhancer
    implements WeightedInstancesHandler, AdditionalMeasureProducer,
    TechnicalInformationHandler { 
  protected int m_BagSizePercent = 100;
  protected boolean m_CalcOutOfBag = false;
  protected double m_OutOfBagError;
  public Bagging() {
   m_Classifier = new weka.classifiers.trees.REPTree();
  }
 
  public String globalInfo() {
   return "Class for bagging a classifier to reduce variance. Can do classification "
        + "and regression depending on the base learner. \n\n"
        + "For more information, see\n\n"
        + getTechnicalInformation().toString();
  }
 
  public TechnicalInformation getTechnicalInformation() {
    TechnicalInformation result;
   result = new TechnicalInformation(Type.ARTICLE);
    result.setValue(Field.AUTHOR, "Leo Breiman");
    result.setValue(Field.YEAR, "1996");
    result.setValue(Field.TITLE, "Bagging predictors");
    result.setValue(Field.JOURNAL, "Machine Learning");
    result.setValue(Field.VOLUME, "24");
    result.setValue(Field.NUMBER, "2");
    result.setValue(Field.PAGES, "123-140");
   return result;
  }
 
  @Override
  protected String defaultClassifierString() {
   return "weka.classifiers.trees.REPTree";
  }
 
  @Override
  public Enumeration listOptions() {
    return null;
  }
 
  @Override
  public void setOptions(String[] options) throws Exception {
   String bagSize = Utils.getOption('P', options);
    if (bagSize.length() != 0) {
      setBagSizePercent(Integer.parseInt(bagSize));
    } else {
      setBagSizePercent(100);
    }
   setCalcOutOfBag(Utils.getFlag('O', options));
   super.setOptions(options);
  }
 
  @Override
  public String[] getOptions() {
   String[] superOptions = super.getOptions();
    String[] options = new String[superOptions.length + 3];
   int current = 0;
    options[current++] = "-P";
    options[current++] = "" + getBagSizePercent();
   if (getCalcOutOfBag()) {
      options[current++] = "-O";
    }
   System.arraycopy(superOptions, 0, options, current, superOptions.length);
   current += superOptions.length;
    while (current < options.length) {
      options[current++] = "";
    }
    return options;
  }
 
  public String bagSizePercentTipText() {
    return "Size of each bag, as a percentage of the training set size.";
  }
 
  public int getBagSizePercent() {
   return m_BagSizePercent;
  }
 
  public void setBagSizePercent(int newBagSizePercent) {
   m_BagSizePercent = newBagSizePercent;
  }
 
  public String calcOutOfBagTipText() {
    return "Whether the out-of-bag error is calculated.";
  }
 
  public void setCalcOutOfBag(boolean calcOutOfBag) {
   m_CalcOutOfBag = calcOutOfBag;
  }
 
  public boolean getCalcOutOfBag() {
   return m_CalcOutOfBag;
  }
 
  public double measureOutOfBagError() {
   return m_OutOfBagError;
  }
 
  public Enumeration enumerateMeasures() {
   Vector newVector = new Vector(1);
    newVector.addElement("measureOutOfBagError");
    return newVector.elements();
  }
 
  public double getMeasure(String additionalMeasureName) {
   if (additionalMeasureName.equalsIgnoreCase("measureOutOfBagError")) {
      return measureOutOfBagError();
    } else {
      throw new IllegalArgumentException(additionalMeasureName
          + " not supported (Bagging)");
    }
  }
 
  @Override
  public void buildClassifier(Instances data) throws Exception {
   // can classifier handle the data?
    getCapabilities().testWithFail(data);
   // remove instances with missing class
    data = new Instances(data);
    data.deleteWithMissingClass();
   super.buildClassifier(data);
   if (m_CalcOutOfBag && (m_BagSizePercent != 100)) {
      throw new IllegalArgumentException("Bag size needs to be 100% if "
          + "out-of-bag error is to be calculated!");
    }
   int bagSize = data.numInstances() * m_BagSizePercent / 100;
    Random random = new Random(m_Seed);
   boolean[][] inBag = null;
    if (m_CalcOutOfBag)
      inBag = new boolean[m_Classifiers.length][];
   for (int j = 0; j < m_Classifiers.length; j++) {
      Instances bagData = null;
     // create the in-bag dataset
      if (m_CalcOutOfBag) {
        inBag[j] = new boolean[data.numInstances()];
        // bagData = resampleWithWeights(data, random, inBag[j]);
        bagData = data.resampleWithWeights(random, inBag[j]);
      } else {
        bagData = data.resampleWithWeights(random);
        if (bagSize < data.numInstances()) {
          bagData.randomize(random);
          Instances newBagData = new Instances(bagData, 0, bagSize);
          bagData = newBagData;
        }
      }
     if (m_Classifier instanceof Randomizable) {
        ((Randomizable) m_Classifiers[j]).setSeed(random.nextInt());
      }
     // build the classifier
      m_Classifiers[j].buildClassifier(bagData);
    }
   // calc OOB error?
    if (getCalcOutOfBag()) {
      double outOfBagCount = 0.0;
      double errorSum = 0.0;
      boolean numeric = data.classAttribute().isNumeric();
     for (int i = 0; i < data.numInstances(); i++) {
        double vote;
        double[] votes;
        if (numeric)
          votes = new double[1];
        else
          votes = new double[data.numClasses()];
       // determine predictions for instance
        int voteCount = 0;
        for (int j = 0; j < m_Classifiers.length; j++) {
          if (inBag[j][i])
            continue;
         voteCount++;
          // double pred = m_Classifiers[j].classifyInstance(data.instance(i));
          if (numeric) {
            // votes[0] += pred;
            votes[0] = m_Classifiers[j].classifyInstance(data.instance(i));
          } else {
            // votes[(int) pred]++;
            double[] newProbs = m_Classifiers[j].distributionForInstance(data
                .instance(i));
            // average the probability estimates
            for (int k = 0; k < newProbs.length; k++) {
              votes[k] += newProbs[k];
            }
          }
        }
       // "vote"
        if (numeric) {
          vote = votes[0];
          if (voteCount > 0) {
            vote /= voteCount; // average
          }
        } else {
          if (Utils.eq(Utils.sum(votes), 0)) {
          } else {
            Utils.normalize(votes);
          }
          vote = Utils.maxIndex(votes); // predicted class
        }
       // error for instance
        outOfBagCount += data.instance(i).weight();
        if (numeric) {
          errorSum += StrictMath.abs(vote - data.instance(i).classValue())
              * data.instance(i).weight();
        } else {
          if (vote != data.instance(i).classValue())
            errorSum += data.instance(i).weight();
        }
      }
     m_OutOfBagError = errorSum / outOfBagCount;
    } else {
      m_OutOfBagError = 0;
    }
  }
 
  @Override
  public double[] distributionForInstance(Instance instance) throws Exception {
   double[] sums = new double[instance.numClasses()], newProbs;
   for (int i = 0; i < m_NumIterations; i++) {
      if (instance.classAttribute().isNumeric() == true) {
        sums[0] += m_Classifiers[i].classifyInstance(instance);
      } else {
        newProbs = m_Classifiers[i].distributionForInstance(instance);
        for (int j = 0; j < newProbs.length; j++)
          sums[j] += newProbs[j];
      }
    }
    if (instance.classAttribute().isNumeric() == true) {
      sums[0] /= m_NumIterations;
      return sums;
    } else if (Utils.eq(Utils.sum(sums), 0)) {
      return sums;
    } else {
      Utils.normalize(sums);
      return sums;
    }
  }
 
  @Override
  public String toString() {
   return null;
  }
 
  @Override
  public String getRevision() {
    return null;
  }
 

}
