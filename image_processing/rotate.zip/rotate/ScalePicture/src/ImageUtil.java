import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class ImageUtil {
	static String initPath=new String();
	static int count=0;
	
	
    public final static void scale(String srcImageFile, String result,
            int scale) {
        try {
            BufferedImage src = ImageIO.read(new File(srcImageFile)); // 读入文件
            int width = src.getWidth(); // 得到源图宽
            int height = src.getHeight(); // 得到源图长
            
            if (width<height)
            {
            		height=scale*height/width;
            		width=scale;
            }
            else {
            		width=scale*width/height;
            		height=scale;
			}
            
            
            Image image = src.getScaledInstance(width, height,
                    Image.SCALE_SMOOTH);
            BufferedImage tag = new BufferedImage(width, height,
                    BufferedImage.TYPE_INT_RGB);
            Graphics g = tag.getGraphics();
            g.drawImage(image, 0, 0, null); // 绘制缩小后的图
            g.dispose();
            ImageIO.write(tag, "JPEG", new File(result));// 输出到文件流
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    static public void ls(String directory)
    {
    		String saveDirString=initPath+File.separator+"scalePics";
		File saveDir=new File(saveDirString);
		if (saveDir.exists()) 
			System.out.println(saveDir.delete());
    		
		File file=new File(directory);
		String[] t=file.list();
		saveDir.mkdir();
		
		
		for (int i=0;i<t.length;i++)
		{
			String str=directory+File.separator+t[i];
			
			File temp=new File(str);
			if(str.endsWith(".jpg")||str.endsWith(".JPG")||str.endsWith(".jpeg"))
			{
				count++;
				String term=saveDirString+File.separator+String.valueOf(count)+".jpg";
				System.out.println(str + " " + term);
				
				ImageUtil.scale(str, term, 100);
			}
			if (temp.isDirectory())
				ls(str);
		}
    }
    
    
    
    
    static public void main(String args[])
    {
    		ImageUtil.initPath=System.getProperty("user.dir");
//    		System.out.println();
    		ImageUtil.ls(ImageUtil.initPath);
    }
}
