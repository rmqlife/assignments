function result=getFeature(a) %a is a imread,  a gray image
b=double(a)/255.0;
% a=rgb2gray(a);
result=[];
a=rgb2hsv(a);
for rgbC=1:3
    temp=a(:,:,rgbC);
%     temp=cropToSquare(temp);
    result=[result,temp(:)'];
%     figure,imshow(temp);
end 
[h,w]=size(result);
%result=result';% row vector
% a=imcrop(a,[80,80]);
% result=a(:)';