
public class Example {
	public double[] x;
	public int target;
	static public double max=0;
	
	
	Example(int[] k)
	{
		target=k[0];
		x=new double[k.length-1];
		for(int i=1;i<k.length;i++){
			x[i-1]=(double)k[i];
			if ((double)k[i]>max)
				max=(double)k[i];
		}
	}
	
	Example(double[] k)
	{
		target=(int)k[0];
		x=new double[k.length-1];
		for(int i=1;i<k.length;i++){
			x[i-1]=(double)k[i];
			if ((double)k[i]>max)
				max=(double)k[i];
		}
	}
	Example(double[] k,int target)
	{
		this.target=target;
		x=new double[k.length];
		for(int i=0;i<k.length;i++){
			x[i]=(double)k[i];
			if ((double)k[i]>max)
				max=(double)k[i];
		}
	}
	
	void rectify()
	{
		for (int i=0;i<x.length;i++)
			x[i]=(double)x[i]/(double)max;
	}
	
	
	void rectify(double k)
	{
		for (int i=0;i<x.length;i++)
			x[i]=(double)x[i]/(double)k;
	}
	
	void debug()
	{
		System.out.println("example debug");
		System.out.print(target+" ");
		for (int i=0;i<x.length;i++)
			System.out.print(x[i]+" ");
		System.out.println();
	}

}
