import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;


public class NeuralNetwork {
	Perceptron[] hidden;
	Perceptron[] output;
	Perceptron[] input;
	List<Example> samples=new ArrayList<Example>();
	double [][] w;
	double [][] wi;
	List<Example> validation;
	List<Example> test;
	static final int TRAIN=1;
	static final int LOAD=0;
	NeuralNetwork(String filename,int tag)
	{
		if (tag==NeuralNetwork.LOAD)
			loadFromFile(filename);
		else if(tag==NeuralNetwork.TRAIN){
			initSamples(filename);
//			rectifySamples(255);
			test=separateRand(samples.size()/10);
			validation=separateRand(samples.size()/5);
		}
	}
	
	void rectifySamples(double k)
	{
		for (int i=0;i<samples.size();i++){
			samples.get(i).rectify(k);
		}
	}
	
	void rectifySamples()
	{
		for (int i=0;i<samples.size();i++){
			samples.get(i).rectify();
		}
	}

	
	void initSamples(String filename)
	{
		File file = new File(filename);
		try{
			if (file.isFile() && file.exists())
			{	
				InputStreamReader read = new InputStreamReader(new FileInputStream(file), "GBK");   
				BufferedReader bufferedReader = new BufferedReader(read);   
				String lineTXT = null;   
				while ((lineTXT = bufferedReader.readLine()) != null) 
				{   
//					System.out.println(lineTXT);
					String[] a = lineTXT.split(" ");//("[^a-zA-Z0-9]+");
					double[] k=new double[a.length];
//					System.out.println("length"+a.length);
					for(int i=0;i<a.length;i++){
						k[i]=Double.valueOf(a[i]);
//						System.out.println(a[i]);
					}
					Example sample=new Example(k);
					samples.add(sample);
				}   
				read.close();
			}
		}catch(IOException e){
			
		}
	}
	
	
	
	List<Example> separateRand(int n){
		List<Example> samples=new ArrayList<Example> ();
		for(int i=0;i<n;i++){
			int k=(int)(samples.size()*Math.random());
			samples.add(this.samples.get(k));
			this.samples.remove(k);
		}
		return samples;
	}
	
	
	List<Example> separate(int n){
		List<Example> samples=new ArrayList<Example> ();
		for(int i=0;i<n;i++){
			int k=0;
			samples.add(this.samples.get(k));
			this.samples.remove(k);
		}
		return samples;
	}
	
	
	public void Backpropagation(int n_in,int n_out,int n_hidden,double speed,int sampleAmount,int times, double delta_bound, double wtemp[][]){
		n_hidden++;
		n_in++;
		hidden=new Perceptron[n_hidden];
		output=new Perceptron[n_out];
		input=new Perceptron[n_in];//for bias
		for (int i=0;i<hidden.length;i++)
			hidden[i]=new Perceptron();
		for (int i=0;i<output.length;i++)
			output[i]=new Perceptron();
		for (int i=0;i<input.length;i++)
			input[i]=new Perceptron();
		input[input.length-1].out=1;
		w=new double[hidden.length][output.length];
		wi=new double[input.length][hidden.length];
		
		
		
		
		//set the initial w
		for	(int i=0;i<n_hidden;i++)
			for	(int j=0;j<n_out;j++){
//				System.out.println(i+" "+j);
				w[i][j]=Math.random()*0.1-0.1;
			}
		if (wtemp==null)
		{
			for	(int i=0;i<n_in;i++)
				for	(int j=0;j<n_hidden;j++)
					wi[i][j]=Math.random()*0.1-0.1;
		}else{
			assert(wtemp.length==wi.length);
			System.out.println(wtemp.length+"wtemp"+wtemp[0].length);
			assert(wtemp[0].length==wi[0].length);
			for	(int i=0;i<n_in;i++)
				for	(int j=0;j<n_hidden;j++)
					wi[i][j]=wtemp[i][j];
		}
		
		
		double maxAccu=0;
		int downTurns=0;
		for (int j=0;j<times;j++)
		{
			for (int i=0;i<sampleAmount;i++)
			{
				Example s=samples.get(i);
				getOutput(s);
				getDelta(s);
				updateW(speed);
//				if (updateW(speed)<delta_bound){
//					System.out.println("finish training at "+j);
//					return;
//				}
			}
			double t=this.getAccuracy(this.validation);
			System.out.println(t);
			if (t>maxAccu){
				maxAccu=t;
				downTurns=0;
			}
			if (t<maxAccu)
				downTurns++;
//			if (downTurns==3)
//				return;	
		}
		System.out.println("not enough times");
	}
	
	
	
	
	
	
	void getOutput(Example sample)
	{
		
//		sample.debug();
		assert(sample.x.length==input.length-1);
		for (int i=0;i<sample.x.length;i++)
		{
			input[i].out=(double)sample.x[i];
		}
//		sigmoid(input,input.length); // should not
		input[input.length-1].out=1; //for bias wi[input.length-1][j]
		
		clearOut(hidden,hidden.length);
		for (int i=0;i<input.length;i++){
			for (int j=0;j<hidden.length;j++)
				hidden[j].out+=input[i].out*wi[i][j];
		}
		
		sigmoid(hidden,hidden.length);
		hidden[hidden.length-1].out=1; //for bias w[hidden.length-1][j]
		
		clearOut(output,output.length);
		for (int i=0;i<hidden.length;i++){
			for (int j=0;j<output.length;j++)
				output[j].out+=hidden[i].out*w[i][j];
		}
		sigmoid(output,output.length);
	}
	
	
	void printOutput(Perceptron[] p)
	{
		System.out.println("print out");
		for (int i=0;i<p.length;i++)
			System.out.println(p[i].out);
	}
	
	void printTarget(Perceptron[] p)
	{
		System.out.println("print target");
		for(int i=0;i<p.length;i++)
			System.out.println(p[i].target);
	}
	
	static public double sigmoid(double y){
//		return 1/(Math.exp(-y)+1);
		return 1/(Math.pow(Math.E, -y)+1);
	}


	void sigmoid(Perceptron[] p,int length)
	{
		for (int i=0;i<length;i++)
			p[i].out=sigmoid((double)p[i].out);
	}
	void clearOut(Perceptron[] p,int length)
	{
		for (int i=0;i<length;i++)
			p[i].out=0;
	}
	
	
	void getDelta(Example sample){
		setOutputTarget(sample.target);
		for (int i=0;i<output.length;i++){
			output[i].delta=(1-output[i].out)*output[i].out*(output[i].target-output[i].out);//.getDelta();
//			output[i].delta=output[i].target-ostput[i].out;

		}
		for (int i=0;i<hidden.length;i++){
			double temp=0;
			for (int j=0;j<output.length;j++)
				temp+=w[i][j]*output[j].delta;
			hidden[i].delta=(1-hidden[i].out)*hidden[i].out*temp;
//			hidden[i].delta=temp;
		}

	}
	
	
	
	
	
	
	double updateW(double speed)
	{
		double max=0;
		for (int i=0;i<hidden.length;i++)
			for (int j=0;j<output.length;j++){
				double delta=speed*output[j].delta*hidden[i].out;
				w[i][j]=w[i][j]+delta;
//				if (Math.abs(delta)>max)
				if(delta>max)
					max=delta;
			}
		
		for (int i=0;i<input.length;i++)
			for (int j=0;j<hidden.length;j++){
				double delta=speed*hidden[j].delta*input[i].out;
				wi[i][j]=wi[i][j]+delta;
//				if (Math.abs(delta)>max)
				if(delta>max)
					max=delta;
			}
		
		return max;
	}
	
	void setOutputTarget(int x)
	{
		for (int i=0;i<output.length;i++)
		{
			output[i].target=0;
		}
		output[x].target=1;
	}
	
	void printMatrix(double w[][]){
		for (int i=0;i<w.length;i++)
		{
			for (int j=0;j<w[0].length;j++)
				System.out.print(w[i][j]+" ");
			System.out.println();
		}
	}
	
	void checkSigmoid()
	{	
		for (int i=-1000;i<1000;i++)
		{
			System.out.println(sigmoid((double)i/100));
		}
	}
	
	 void saveToFile(String outname){
		 	File f=new File(outname);
		 	String s=new String();
		 	s=s+input.length+","+output.length+"," +hidden.length+"\n";
			
			for (int i=0;i<hidden.length;i++){
				for (int j=0;j<output.length-1;j++){
					s=s+w[i][j]+",";
				}
				s=s+w[i][output.length-1]+"\n";
			}
			
			for (int i=0;i<input.length;i++){
				for (int j=0;j<hidden.length-1;j++)
					s=s+wi[i][j]+",";
				
				s=s+wi[i][hidden.length-1]+"\n";
			}
			
//			if (f.exists()==false)
				try {
//					f.createNewFile();
					BufferedWriter out = new BufferedWriter(new FileWriter(f));
					out.write(s);
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
//			System.out.print(s);
	 }
	
	 void loadFromFile(String filename){
			File file = new File(filename);

			InputStreamReader read;
			try {
				read = new InputStreamReader(new FileInputStream(file), "GBK");
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTXT=bufferedReader.readLine();
				String []t=lineTXT.split(",");
				int n_in=Integer.valueOf(t[0]);
				int n_out=Integer.valueOf(t[1]);
				int n_hidden=Integer.valueOf(t[2]);
				hidden=new Perceptron[n_hidden];
				output=new Perceptron[n_out];
				input=new Perceptron[n_in];//for bias
				for (int i=0;i<input.length;i++)
					input[i]=new Perceptron();
				for (int i=0;i<output.length;i++)
					output[i]=new Perceptron();
				for (int i=0;i<hidden.length;i++)
					hidden[i]=new Perceptron();
				w=new double[hidden.length][output.length];
				wi=new double[input.length][hidden.length];
				int tempi=0;
				while ((lineTXT = bufferedReader.readLine()) != null)
				{
//					System.out.println(lineTXT);
					String[] a = lineTXT.split(",");//("[^a-zA-Z0-9.]+");
					double[] k;
					if (tempi < hidden.length)
						k=new double[output.length];
					else
						k=new double[hidden.length];
					for(int i=0;i<k.length;i++){
//						System.out.println(a[i]);
						k[i]=Double.valueOf(a[i]);
						
					}
					if (tempi < hidden.length)
						w[tempi]=k;
					else
						wi[tempi-hidden.length]=k;
					tempi++;
				}
				read.close();
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e)
			{
				e.printStackTrace();
			}
			
	 }
	 
	int getResult(Example sample){
		getOutput(sample);
		double max=0;
		int maxi=-1;
		for (int i=0;i<output.length;i++)
			if (output[i].out>max){
				max=output[i].out;
				maxi=i;
			}
		return maxi;
	}
	
	double getRawResult(Example sample){
		getOutput(sample);
		double max=0;
		int maxi=-1;
		for (int i=0;i<output.length;i++)
			if (output[i].out>max){
				max=output[i].out;
				maxi=i;
			}
		return max;
	}
	
	double getAccuracy(List<Example> le)
	{
		int right=0;
		for (int i=0;i<le.size();i++)
		{
			Example e=le.get(i);
			if (e.target==this.getResult(e))
				right++;
		}
		double r=(double)right/(double)le.size();
		return r;
	}
	
	
	static public void main(String args[]){
//		RBM rbm = new RBM("/Users/jzd/Documents/testfile/feature.txt",100,180);
//		rbm.preTrain(10,20);
		
		System.out.println("Back Probagation");
		String s1=new String("/Users/jzd/Documents/testfile/feature.txt");
		NeuralNetwork nn=new NeuralNetwork(s1,NeuralNetwork.TRAIN);
		nn.samples.get(0).debug();
		nn.Backpropagation(300, 4, 50, 0.5,nn.samples.size() ,500, 0.000001,null);//rbm.transferWi());//for digit
		String s2="/Users/jzd/Documents/testfile/rotate.w";
		nn.saveToFile(s2);
		
		NeuralNetwork nn2=new NeuralNetwork(s2,NeuralNetwork.LOAD);
		nn2.initSamples(s1);
		nn2.test=nn2.samples;

		//		nn.Backpropagation(20, 10, 80, 0.5, nn.samples.size(), 1000, 0.000001,rbm.transferWi());//for digit
		System.out.println("for test:"+nn.getAccuracy(nn.test));
		System.out.println("for test:"+nn2.getAccuracy(nn2.test));
	}
}
