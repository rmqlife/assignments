import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class ImageUtil {
	static int count=0;
	static final int targetSize=10;
	
	
	 /**
     * 取得图像上指定位置像素的 rgb 颜色分量。
     * @param image 源图像。
     * @param x 图像上指定像素位置的 x 坐标。
     * @param y 图像上指定像素位置的 y 坐标。
     * @return 返回包含 rgb 颜色分量值的数组。元素 index 由小到大分别对应 r，g，b。
     */
    public static int[] getRGB(BufferedImage image, int x, int y){
        int[] rgb = new int [3];
        int pixel = image.getRGB(x, y);
         rgb[0] = (pixel >> 16) & 0xFF;
         rgb[1] = (pixel >> 8) & 0xFF;
         rgb[2] = pixel & 0xFF;
        return  rgb;
    }
    
	
	
    public final static double[] scale(String srcImageFile, String result,
            int scale) {
        try {
            BufferedImage src = ImageIO.read(new File(srcImageFile)); // 读入文件
            Image image =src.getScaledInstance(scale, scale,Image.SCALE_SMOOTH);
            BufferedImage buffered = new BufferedImage(scale, scale,  BufferedImage.TYPE_INT_RGB);
            buffered.getGraphics().drawImage(image, 0, 0 , null);
            double [][][]temp=new double[scale][scale][3];
            
            for (int i=0;i<scale;i++)
            	for (int j=0;j<scale;j++)
            	{
            		int []p=getRGB(buffered, i, j);
            		float[] hsv = new float[3];
            		Color.RGBtoHSB(p[0],p[1],p[2],hsv);
            		for (int r=0;r<3;r++){
            			temp[i][j][r]=hsv[r];
            		}
            	}
            
            
            double []ans=new double[scale*scale*3];
            int count=0;
			for (int k=0;k<3;k++)
				for (int i=0;i<scale;i++)
            			for (int j=0;j<scale;j++)
            			{
            				ans[count]=temp[i][j][k];
            				count++;		
            			}
//            for (int i=0;i<count;i++)
//            		System.out.println(ans[i]);
          ImageIO.write(buffered, "JPEG", new File(result));// 输出到文件流

            return ans;
//		for (int k=0;k<3;k++){	
//			for (int i=0;i<scale;i++)
//			{
//				for (int j=0;j<scale;j++)
//					System.out.print(temp[i][j][k]+" ");
//				System.out.println();
//			}
//			System.out.println();
//		}
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
    }
    
    static public void ls(String directory) throws IOException
    {
    		String saveDirString=directory+File.separator+"rotatePics";
		File saveDir=new File(saveDirString);
		if (saveDir.exists()) 
			System.out.println(saveDir.delete());
    		
		File file=new File(directory);
		String[] t=file.list();
		saveDir.mkdir();
		
		
		for (int i=0;i<t.length;i++)
		{
			String str=directory+File.separator+t[i];
			
			File temp=new File(str);
			if(str.endsWith(".jpg")||str.endsWith(".JPG")||str.endsWith(".jpeg"))
			{
				count++;
				String term=saveDirString+File.separator+t[i];
				System.out.println(str + " " + term);
				process(str, term);
				
			}
			if (temp.isDirectory())
				ls(str);
		}
    }
    
    
    public static BufferedImage rotateImage(final BufferedImage bufferedimage,
            final int degree){
        int w= bufferedimage.getWidth();// 得到图片宽度。
        int h= bufferedimage.getHeight();// 得到图片高度。
        int type= bufferedimage.getColorModel().getTransparency();// 得到图片透明度。
        BufferedImage img;// 空的图片。
        Graphics2D graphics2d;// 空的画笔。
        (graphics2d= (img= new BufferedImage(w, h, type))
                .createGraphics()).setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2d.rotate(Math.toRadians(degree), w / 2, h / 2);// 旋转，degree是整型，度数，比如垂直90度。
        graphics2d.drawImage(bufferedimage, 0, 0, null);// 从bufferedimagecopy图片至img，0,0是img的坐标。
        graphics2d.dispose();
        return img;// 返回复制好的图片，原图片依然没有变，没有旋转，下次还可以使用。
    }
    
    static public void process(String src, String dst) throws IOException
    {
    		double[] k=scale(src, "/Users/jzd/Pictures/last.jpeg",10);
    		Example m=new Example(k,-1);
    		NeuralNetwork nn2=new NeuralNetwork("/Users/jzd/Documents/testfile/rotate.w",NeuralNetwork.LOAD);
    		int ans=nn2.getResult(m);
    		System.out.print(ans);
    		
    		BufferedImage b = ImageIO.read(new File(src)); // 读入文件
    		b=rotateImage(b, ans*90);
        ImageIO.write(b, "JPEG", new File(dst));// 输出到文件流
//    		m.debug();
    }
    
    static public void processFolder(String dir)
    {
    	
    }
    
    
	static public NeuralNetwork nn2;
	
    
    static public void main(String args[]) throws IOException
    {
    			String s1="/Users/jzd/Pictures/2013春节期间照片 085.jpg";
        		nn2=new NeuralNetwork("/Users/jzd/Documents/testfile/rotate.w",NeuralNetwork.LOAD);	
//    			process(s1, "/Users/jzd/Pictures/hehe.jpeg");
//    		System.out.println(m.x.length);
        		ls("/Users/jzd/Pictures/yuan/tw/136NIKON");
    }
}
