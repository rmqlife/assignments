mydir='/Users/jzd/Pictures/yuan/test/';
mydir='/Users/jzd/Pictures/yuan/Train400Img/';
mydir='/Users/jzd/Pictures/yuan/tw/131NIKON/';
%   /Users/jzd/Pictures/yuan/Train400Img
DIRS=dir([mydir,'*.jpg']); 
n=length(DIRS);

result=[];
for i=1:n
    if ~DIRS(i).isdir % ~ means not
        filename=[mydir,DIRS(i).name]
        im=imread(filename);
        [h,w]=size(im);
        t=max(h,w);
        im=imresize(im,[20,20]);
        
        for j=0:3
            im0 = imrotate(im,90*j,'nearest','loose');
            ans=[j,getFeature(im0)];
            result=[result;ans];
%             figure,imshow(im0);
        end
    end
end

printM(result);