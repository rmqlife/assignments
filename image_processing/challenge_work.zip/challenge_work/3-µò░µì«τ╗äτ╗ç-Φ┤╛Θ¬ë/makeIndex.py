import sqlite3
import os
import os.path
filename='index.db'
tsvname='res.tsv'
#os.remove(filename)
cx=sqlite3.connect(filename)
cu=cx.cursor()
tablehead="""create table tags (name varchar(10) UNIQUE,
           im0 varchar(20),c0 integer,
           im1 varchar(20),c1 integer,
           im2 varchar(20),c2 integer,
           im3 varchar(20),c3 integer,
           im4 varchar(20),c4 integer)"""
#cu.execute(tablehead)

count=0;
s=[]
tsvData=open(tsvname,'r')
for line in tsvData:
        s=line.split('\t')
        
        if len(s)>15 and int(s[2])>200:
                #put into db
                l=[]
                l=[s[0],s[1],int(s[2]),s[3],int(s[4]),s[5],int(s[6]),s[7],int(s[8]),s[9],int(s[10])];
                count=count+1
                cx.execute("insert or replace into tags values (?,?,?,?,?,?,?,?,?,?,?)", l)
                if count%1000==0:
                        print s[0]
                        print count
                        cx.commit()


cx.commit()
