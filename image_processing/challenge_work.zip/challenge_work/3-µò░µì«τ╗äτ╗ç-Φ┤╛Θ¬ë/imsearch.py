import os, base64
import sqlite3
import time
def getIndex(tag):
        k=[];
        id_cu.execute("select * from tags where name='%s'"%tag)
        k=id_cu.fetchone()
        return k
def getImage(imageName,targetName):
        k=[];
        im_cu.execute("select image from devImages where name='%s'"%imageName) #,imageName)
        k=im_cu.fetchall()
        datastr=k[0][0];
        imgData = base64.b64decode(datastr)
        img = open(targetName+'.jpg','wb')
        img.write(imgData)
        img.close()
        return 0


def search(raw):
        k=[]
        k=raw.split();
        print k
        for word in k:
                wordentry=getIndex(word)
                if wordentry!=None:
                        print word
                        for k in range(0,5):
                                print 'count'+str(k)+":"+str(wordentry[2*k+2])
                                getImage(wordentry[2*k+1],str(k))



#initial and handler
id_filename='index.db'
id_cx=sqlite3.connect(id_filename)
id_cu=id_cx.cursor()
im_filename='hehe.db'
im_cx=sqlite3.connect(im_filename)
im_cu=im_cx.cursor()

#input="air condition"
while 1:
        start=time.clock();
        raw=raw_input("search image:")
        search(raw)
        print "search cost:"+str(time.clock()-start)+"s";
#raw="search engine"
