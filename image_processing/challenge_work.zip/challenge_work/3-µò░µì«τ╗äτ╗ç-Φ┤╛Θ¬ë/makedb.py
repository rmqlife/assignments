import sqlite3
import os
import os.path
filename='hehe.db'
tsvname='TrainImageSet.tsv'
os.remove(filename)
cx=sqlite3.connect(filename)
cu=cx.cursor()
cu.execute("create table devImages (name varchar(10) PRIMARY KEY,image text NULL)")

count=0;
s=[]
tsvData=open(tsvname,'r')
for line in tsvData:
        s=line.split('\t')
	if s[0]!=[]:
		cx.execute("insert into devImages values (?,?)", s)
		count=count+1
	if count % 1000 == 0:
		print count
		cx.commit();
#cu.execute("select name from devimages")
#print cu.fetchall()
#cu.execute("update catalog set name='Boy' where id = 0")
cx.commit()
