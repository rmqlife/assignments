makedb.py make the database of images
makeindex.py make the database of tags
imsearch use to search the image