function [ sc ] = score(p ,num, c1, c2, c3, c4, c5, CACHE)

tic

chk = 1;
if nargin >= 7
    if CACHE ~= 0 && exist('tmp.mat') == 2    % ʹ����ǰ���ɵ��������洢��tmp.mat�У�
        vt = load('tmp.mat');
        vs = vt.vs;
        chk = 0;
    end
end

if chk ~= 0
    img1 = imread(p);
    [vs] = getFeature(img1);
    save('tmp.mat', 'vs');
end

[m,~] = size(vs);
v = zeros([m, num]);
for i = 1:num
    str = strcat(num2str(i), '.jpg');
    img = imread(str);
    v(:,i) = getFeature(img);
end

% (��׼������)
M = mean(v, 2)*0;
S = std(v,0,2);
for i = 1:num
   v(:,i) = (v(:,i)-M)./S;
end
vs = (vs-M)./S;

% ��׼ŷ�Ͼ���
% dist = pdist([vs, v]', 'seuclidean');

%toc


% S���ţ����飩
Sa = [
    ones([15*8 1])/4/5;
    ones([7 1])/4*1.25;
    ones([7 1])/4*0.75;
    ones([8*8 1])/4
    ];

% Scroing
for i=1:num
    v(:,i) = v(:,i).*Sa;
end
vs = vs.*Sa;
dist = pdist([vs, v]');
cc = [c1, c2, c3, c4, c5];
cc = cc/sum(cc);
d2 = norm((dist(1,1:num).^2).*cc);
ea = mean(dist(1,num+1:num*(num-1)/2));
eb = 0.01;
sc = exp(-eb*ea*d2);

toc

end

