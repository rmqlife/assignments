function [ v ] = getFeature( img )

%function [ f_hsv, f_hu, f_chen, f_gabor ] = getFeature( img )

%tic

[m,n,~] = size(img);
while m > 128 || n > 128
    m = floor(m/2);
    n = floor(n/2);
    img = imresize(img, [m n]);
    [m,n,~] = size(img);
end
grayimg = rgb2gray(img);
bwimg = edge(grayimg);
rimg = imresize(grayimg, [32 32]);

v = zeros([8*15+2*7+8*8 1]);

%% HSVֱ��ͼ
[f1,f2,f3,f4,f5] = HSV(img);
%f_hsv = [f1,f2,f3,f4,f5];
v(1:120,1) = [
    f1(:,1);f1(:,2);f1(:,3);
    f2(:,1);f2(:,2);f2(:,3);
    f3(:,1);f3(:,2);f3(:,3);
    f4(:,1);f4(:,2);f4(:,3);
    f5(:,1);f5(:,2);f5(:,3);
    ]/(m*n);

%% �����
f_hu = huInvarM(grayimg);
f_chen = chenInvarM(bwimg);
v(121:134) = [f_hu';f_chen'];

%% Gabor
filter_bank = construct_Gabor_filters_PhD(6, 4, [32 32]);
filtered_image = filter_image_with_Gabor_bank_PhD(rimg,filter_bank, 16);
num_of_pixels = sqrt(length(filtered_image)/(6*4));
for i = 1:8    
    f_gabor = reshape(filtered_image((i - 1) * num_of_pixels * num_of_pixels + 1 :i * num_of_pixels * num_of_pixels), num_of_pixels, num_of_pixels);
end
for i = 1:8
    v(135+(i-1)*8:135+(i-1)*8+7, 1) = f_gabor(:,i);
end

%toc

end

