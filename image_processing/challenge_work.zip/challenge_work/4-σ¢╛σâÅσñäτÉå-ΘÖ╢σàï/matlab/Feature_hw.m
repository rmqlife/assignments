function [m_h, m_s, m_v] = Feature_hw(in1)
%745, 7 for H, 4 for S, 5 for V
[h, w, z] = size(in1);
% m_h = zeros(129,1);
% m_s = zeros(17,1);
% m_v = zeros(33,1);
% for i = 1:h
%     for j = 1:w
%         h = 1 + round(in1(i,j,1) * 128);
%         s = 1 + round(in1(i,j,2) * 16);
%         v = 1 + round(in1(i,j,3) * 32);
%         m_h(h,1) = m_h(h,1) + 1;
%         m_s(s,1) = m_s(s,1) + 1;
%         m_v(v,1) = m_v(v,1) + 1;
%     end
% end
m_h = zeros([8 1]);
m_s = m_h;
m_v = m_h;
for i = 1:h
    m_h = m_h + hist(in1(i,:,1), 8)';
    m_s = m_s + hist(in1(i,:,1), 8)';
    m_v = m_v + hist(in1(i,:,1), 8)';
end

end
