function [f1,f2,f3,f4,f5] = HSV(I)
%return 5 * 3 matrixes;
in1 = rgb2hsv(I);
[h,w,~] = size(in1);
[h1,s1,v1] = Feature_hw(in1(1:floor(h/2), 1:floor(w/2), :));
[h2,s2,v2] = Feature_hw(in1(1:floor(h/2), floor(w/2)+1:w, :));
[h3,s3,v3] = Feature_hw(in1(floor(h/2)+1:h, 1:floor(w/2), :));
[h4,s4,v4] = Feature_hw(in1(floor(h/2)+1:h, floor(w/2)+1:w, :));
[h5,s5,v5] = Feature_hw(in1(floor(h/4)+1:3*floor(h/4), floor(w/4)+1:3*floor(w/4), :));
f1 = [h1,s1,v1];
f2 = [h2,s2,v2];
f3 = [h3,s3,v3];
f4 = [h4,s4,v4];
f5 = [h5,s5,v5];

end