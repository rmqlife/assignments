import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

class myImage
{
	public String image;
	public int count;
	public myImage()
	{
		image = "";
		count = 0;
	}
	public myImage(String str, int ct)
	{
		image = str;
		count = ct;
	}
}

class imageMap
{
	public HashMap<String, Integer> immap = new HashMap<String, Integer>();
	public imageMap() {
		// TODO Auto-generated constructor stub
	}
	public imageMap(HashMap<String, Integer> map)
	{
		immap = map;
	}
}

public class LanProc {
	public HashSet<String> stopWordSet = new HashSet<String>();
	public HashMap<String, imageMap> tagMap = new HashMap<String, imageMap>();
	public void generateStopSet(String inFileName) throws IOException{
		try {
			FileInputStream in = new FileInputStream(inFileName);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String word;
			while((word = br.readLine()) != null){
				if(word != null)
					stopWordSet.add(word);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//System.out.println("cannot find the file");
		}
	}
	
	//ɾ��ͣ�ô�
	public String DeleteStopWord(String str) 
	{
		String [] words = str.split("[^A-Za-z0-9]");
		String ans = "";
		for(int i = 0; i < words.length; i++)
		{
			if(stopWordSet.contains(words[i]))
			{
				continue;
			}
			else
			{
				ans += words[i] + " ";
			}
		}
		
		return ans;
	}
	
	//query ����
	public String QueryWork(String str)
	{
		String tmp = DeleteStopWord(str);
		Stemmer ste = new Stemmer();
		String ans = ste.stem(tmp);
		
		return ans;
	}
	
	public void Work_on_single_line(String line)
	{
		String image = "";
		String query = "";
		int click_num = 0;
		
		String tmp[] = line.split("\t");
		/*for(int i = 0; i < tmp.length; i++)
		{
			System.out.print("" + i + tmp[i] + " ");
		}*/
		//System.out.println();
		image = tmp[0];
		query = tmp[1];
		click_num = Integer.valueOf(tmp[2]);
		//System.out.println("image:"+image+"\tquery:"+QueryWork(query)+"\tclicknum:"+click_num);
		String tags[] = QueryWork(query).split("[^A-Za-z0-9]+");
		//System.out.print(tags[0]);
		for(int i = 0; i < tags.length; i++)
		{
			if(tags[i].isEmpty())
				continue;
			//�ж��Ƿ���tag�����У����Ѵ��ڸôʣ������tagmap
			if(tagMap.containsKey(tags[i]))
			{
				//��ȡÿ��tag����Ӧ�ĵ�ͼƬ�б�
				HashMap<String, Integer> tmpmap = tagMap.get(tags[i]).immap;
				//�ж��Ƿ��ͼƬ����immap��
				if(tmpmap.containsKey(image))
					tmpmap.put(image, tmpmap.get(image)+click_num);
				else
					tmpmap.put(image, click_num);
				tagMap.put(tags[i], new imageMap(tmpmap));
			}
			else
			{
				HashMap<String, Integer> tmpmap = new HashMap<String, Integer>();
				tmpmap.put(image, click_num);
				tagMap.put(tags[i], new imageMap(tmpmap));
			}
		}
		//Iterator iter = tagMap.entrySet().iterator();
		
		/*while(iter.hasNext()) 
		{
			Map.Entry entry = (Map.Entry)iter.next();
	���� 		Object key = entry.getKey();
	���� 		Object val = entry.getValue();
	���� 		
	����  	}*/
	}
	
	//����dataset
	public void work() throws FileNotFoundException
	{
		String inFileName = "dataset\\TrainClickLog.tsv";
		FileInputStream in = new FileInputStream(inFileName);
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;
		int i = 0;
		//int i = 1000;
		try {
			while((line = br.readLine()) != null && i < 30000000){
					//line = br.readLine();
					i++;
					System.out.println(i);
					if(i >= 20000000)
						Work_on_single_line(line);
					//i--;
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}
	
	public void output() throws FileNotFoundException
	{
		String rootFileName = "res\\res2\\";
		String word, ima;
		int counter;
		Iterator itertag = tagMap.keySet().iterator();
		
		String outFileName = rootFileName+"res.tsv";
		FileWriter out = null;
		try {
			out = new FileWriter(outFileName, true);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		while(itertag.hasNext())
		{
			word = (String) itertag.next();
			//System.out.println(word+":");
			try {
				out.write(word);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			HashMap<String, Integer> tmp1 = (HashMap<String, Integer>) tagMap.get(word).immap;
			
			List<Map.Entry<String, Integer>> entryList = new ArrayList<Map.Entry<String, Integer>>(tmp1.entrySet());
			Collections.sort(entryList,new Comparator<Map.Entry<String, Integer>>() {

				@Override
				public int compare(Entry<String, Integer> o1,
						Entry<String, Integer> o2) {
					// TODO Auto-generated method stub
					int v1 = 0,v2 = 0;
					try{
						v1 = o1.getValue();
						v2 = o2.getValue();
					}catch(NumberFormatException e){
						v1 = 0;
						v2 = 0;
					}
					return v2 - v1;
				}
			});
			
			Iterator<Map.Entry<String, Integer>> iterim = (Iterator<Entry<String, Integer>>) entryList.iterator();
			Map.Entry<String, Integer> tempEntry = null;
			while(iterim.hasNext())
			{
				tempEntry = iterim.next();
				ima = tempEntry.getKey();
				counter = tempEntry.getValue();
				
				//System.out.println(ima + "\t"+counter);
				try {
					out.write(("\t"+ima + "\t" + counter));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try {
				out.write("\r\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println("**************");
		}
		try {
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws IOException
	{
		LanProc process = new LanProc();
		/*String str = "I'm loving my girlfriend   deeply, to be honest.";
		String tmp[] = str.split("[^A-Za-z0-9]+");
		for(int i = 0; i < tmp.length; i++)
			System.out.println(tmp[i]);*/
		process.generateStopSet("stop_words.txt");
		
		process.work();
		
		process.output();
		
		System.out.println("Finished!");
	}
}
